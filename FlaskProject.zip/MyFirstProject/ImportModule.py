import ModuleTest

mylist = [10,20,30]
ModuleTest.changval( mylist )
print ("Values outside the function: ", mylist)