import math   # This will import math module
print ("math.ceil(-45.17) : ", math.ceil(-45.17))
print ("math.ceil(-45.66) : ", math.ceil(-45.66))
print ("math.ceil(100.12) : ", math.ceil(100.12))
print ("math.ceil(100.72) : ", math.ceil(100.72))
print ("math.ceil(math.pi) : ", math.ceil(math.pi))

var1 = 'Hello World!'
print ("Updated String :- ", var1[:6] + 'Python') #Hello Python

print ('C:\\nowhere')
print (r'C:\\nowhere')

str = "this is string."
print ("str.capitalize() : ", str.capitalize())
print ("str.center(40, '*') : ", str.center(40, '*'))
print ("str.count('i') : ", str.count('i'))
sub = 'is'
print ("str.count('is', 10, 40) : ", str.count(sub,0,40))
print ("len(str) : ", len(str))
