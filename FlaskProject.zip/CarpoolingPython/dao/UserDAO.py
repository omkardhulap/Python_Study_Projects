'''
Created on Oct 24, 2017

@author: omkar.d
'''
from beans.UserDetails import UserDetails

def saveUserDetails(self):
    '''
    TODO: call database and save self 
    '''
    return True

def getUserDetailsByEmail(self):
    '''
    TODO: call database by self id and populate UserDetails 
    '''
    return UserDetails

def listAllUsers():
    '''
    TODO: call database and get all UserDetails 
    '''
    list
    return list