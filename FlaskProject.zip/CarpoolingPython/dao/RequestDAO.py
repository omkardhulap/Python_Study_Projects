'''
Created on Oct 24, 2017

@author: omkar.d
'''
from beans.RequestDetails import RequestDetails

def getRequestById(self):
    '''
    TODO: call database by self id and populate RequestDetails 
    '''
    return RequestDetails
    
def getRequestByLocation(self):
    '''
    TODO: call database by self location and populate RequestDetails 
    '''
    return RequestDetails

def saveRequest(self):
    '''
    TODO: call database and save self 
    '''
    return True

def deleteRequestById(self):
    '''
    TODO: call database and delete by self 
    '''
    return True
